//**************************************************************** << In God We Trust >> ***************************************************************************/
var width = window.innerWidth;
var height = window.innerHeight;
var camera, renderer, scene;
var spotLight;
var controls;
var tween;
var target = { x: 10, y: 0, z: 0 };
//physics
var surfaceMesh, groundBody, groundShape, ball, ballBody, ballShape, table, tableBody, tableShape, wall, wallBody, wallShape;
var pin, pinBody, pinShape;
var boxP, boxPBody, boxPShape;
var mass, world, timeStep = 1 / 60;
var cannonDebugRenderer;
var phsyicRenderer = false;
var time;
var counter1 = 0, counter2 = 0;
var balls = [];
var countBall = 0;
var ballsBodys = [];
var pinArray = [];
var pinArrayBody = [];
var scores =0;
var scorePage;
var leftRingWallMesh, rightRingWallMesh;
var tableMesh
var leftRingWallBody, rightRingWallBody, frontWallMesh
var testMesh, testMesh10;
var power = 0;
var objectMesh, objectBody;
var flag1 = 1;


init();

initCannon();

animate();

async function init() {
    scene = new THREE.Scene();

    //  Create a camera, which defines where we're looking at.
    camera = new THREE.PerspectiveCamera(45, width / height, 0.1, 1000);

    //  Create a render and set the size
    renderer = new THREE.WebGLRenderer({ antialias: true });
    renderer.setClearColor(new THREE.Color(0x000000));
    renderer.setSize(width, height);
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;



    //?? << Position and point the camera to the center of the scene >>
    camera.position.x = 0;
    camera.position.y = 6;
    camera.position.z = 25;

    camera.lookAt(scene.position);


    //? << Add Sound >>
    var listener = new THREE.AudioListener();
    camera.add(listener);
    var sound = new THREE.Audio(listener);
    var audioLoader = new THREE.AudioLoader();
    audioLoader.load('music/Misirlou.mp3', function (buffer) {
        sound.setBuffer(buffer);
        sound.setLoop(true);
        sound.setVolume(0.5);
        sound.play();
    });


    //?? << Add the output of the renderer to the html element >>
    document.getElementById("web-gl").appendChild(renderer.domElement);
    window.addEventListener('resize', onWindowResize, false);
    window.addEventListener('keyup', onDocumentKeyUp, false);
    window.addEventListener('keydown', onDocumentKeyDown, false);


    //********************************** << Background and Floor (Scene) >> ****************************************
    //? << World Picture >>
    // let urls = [
    //     'world/posx.jpg', 'world/negx.jpg',
    //     'world/posy.jpg', 'world/negy.jpg',
    //     'world/posz.jpg', 'world/negz.jpg'
    // ];

    // let loader = new THREE.CubeTextureLoader();
    // scene.background = loader.load(urls);
    //?

    //? << Point Wall >> 
    var pointWallTexture = THREE.ImageUtils.loadTexture("texture/pointWall.jpg");
    pointWallTexture.magFilter = THREE.NearestFilter;
    pointWallTexture.minFilter = THREE.NearestFilter;
    var pointWallGeometry = new THREE.BoxGeometry(19.3, 7.0, 2.0);
    var pointWallMaterial = new THREE.MeshPhongMaterial({
        map: pointWallTexture,
        shading: THREE.SmoothShading
    });
    pointWallMesh = new THREE.Mesh(pointWallGeometry, pointWallMaterial);
    pointWallMesh.castShadow = false;
    pointWallMesh.receiveShadow = false;
    pointWallMesh.position.set(0, -1, -55);
    scene.add(pointWallMesh);
    

    //? << front wall >>
    let frontWallTexture = THREE.ImageUtils.loadTexture("texture/frontWall.jpg");
    frontWallTexture.repeat.set(3, 5);
    frontWallTexture.wrapS = THREE.RepeatWrapping;
    frontWallTexture.wrapT = THREE.RepeatWrapping;
    frontWallTexture.minFilter = THREE.NearestFilter;
    let frontWall = new THREE.PlaneGeometry(50, 25);
    let frontWallMaterial = new THREE.MeshPhongMaterial({
        color: 0xcccccc,
        side: THREE.DoubleSide,
        map: frontWallTexture
    });
    frontWallMesh = new THREE.Mesh(frontWall, frontWallMaterial);
    frontWallMesh.position.z = -55;
    frontWallMesh.receiveShadow = true;
    scene.add(frontWallMesh);
    //?

    //? << Right Front Wall >>
    var testMesh1 = THREE.ImageUtils.loadTexture('texture/frontWall.jpg');
    testMesh1.repeat.set(1, 2);
    testMesh1.wrapS = THREE.RepeatWrapping;
    testMesh1.wrapT = THREE.RepeatWrapping;
    testMesh1.minFilter = THREE.NearestFilter;
    var testMeshg = new THREE.BoxGeometry(16.7, 8, 6);
    var testMeshm = new THREE.MeshPhongMaterial({
        map: testMesh1,
        shading: THREE.SmoothShading
    });
    testMesh = new THREE.Mesh(testMeshg, testMeshm);
    testMesh.castShadow = true;
    testMesh.receiveShadow = true;
    scene.add(testMesh);
    //?

    //? << Left Front Wall >>
    var testMesh11 = THREE.ImageUtils.loadTexture('texture/frontWall.jpg');
    testMesh11.repeat.set(1, 2);
    testMesh11.wrapS = THREE.RepeatWrapping;
    testMesh11.wrapT = THREE.RepeatWrapping;
    testMesh11.minFilter = THREE.NearestFilter;
    var testMeshg1 = new THREE.BoxGeometry(16.7, 8, 6);
    var testMeshm1 = new THREE.MeshPhongMaterial({
        map: testMesh11,
        shading: THREE.SmoothShading
    });
    testMesh10 = new THREE.Mesh(testMeshg1, testMeshm1);
    // leftRingWallMesh.position.set(-10.0, -6.5, -23.0);
    testMesh10.castShadow = true;
    testMesh10.receiveShadow = true;
    scene.add(testMesh10);
    //?

    //? << Left Wall >>
    let leftWallTexture = THREE.ImageUtils.loadTexture('texture/leftWall.jpg')
    leftWallTexture.repeat.set(3, 3);
    leftWallTexture.wrapS = THREE.RepeatWrapping;
    leftWallTexture.wrapT = THREE.RepeatWrapping;
    leftWallTexture.minFilter = THREE.NearestFilter;
    let leftWallGeometry = new THREE.BoxGeometry(0.5, 42, 80);
    let leftWallMaterial = new THREE.MeshPhongMaterial({
        map: leftWallTexture,
        shading: THREE.SmoothShading
    });
    leftWallMesh = new THREE.Mesh(leftWallGeometry, leftWallMaterial);
    leftWallMesh.position.set(-25, -2, -20)
    leftWallMesh.castShadow = false;
    leftWallMesh.receiveShadow = false;
    scene.add(leftWallMesh);
    //?

    //? << Left Ring Wall >>
    let leftRingWallTexture = THREE.ImageUtils.loadTexture('texture/ringWall.jpg');
    leftRingWallTexture.repeat.set(4, 1);
    leftRingWallTexture.wrapS = THREE.RepeatWrapping;
    leftRingWallTexture.wrapT = THREE.RepeatWrapping;
    leftRingWallTexture.minFilter = THREE.NearestFilter;
    let leftRingWallGeometry = new THREE.BoxGeometry(0.5, 1.5, 75.0);
    let leftRingWallMaterial = new THREE.MeshPhongMaterial({
        map: leftRingWallTexture,
        shading: THREE.SmoothShading
    });
    leftRingWallMesh = new THREE.Mesh(leftRingWallGeometry, leftRingWallMaterial);
    // leftRingWallMesh.position.set(-10.0, -6.5, -23.0);
    leftRingWallMesh.castShadow = true;
    leftRingWallMesh.receiveShadow = true;
    scene.add(leftRingWallMesh);
    //?

    //? << Right Wall >>
    let rightWallTexture = THREE.ImageUtils.loadTexture('texture/rightWall.jpg');
    rightWallTexture.repeat.set(2, 1);
    rightWallTexture.wrapS = THREE.RepeatWrapping;
    rightWallTexture.wrapT = THREE.RepeatWrapping;
    rightWallTexture.minFilter = THREE.NearestFilter;
    let rightWallGeometry = new THREE.BoxGeometry(0.5, 42.0, 80);
    let rightWallMaterial = new THREE.MeshPhongMaterial({
        map: rightWallTexture,
        shading: THREE.SmoothShading
    });
    let rightWallMesh = new THREE.Mesh(rightWallGeometry, rightWallMaterial);
    rightWallMesh.position.set(25, -2, -20);
    rightWallMesh.castShadow = true;
    rightWallMesh.receiveShadow = true;
    scene.add(rightWallMesh);
    //?

    //? << Right Ring Wall >>
    var rightRingWall = THREE.ImageUtils.loadTexture('texture/ringWall.jpg');
    rightRingWall.repeat.set(4, 1);
    rightRingWall.wrapS = THREE.RepeatWrapping;
    rightRingWall.wrapT = THREE.RepeatWrapping;
    rightRingWall.minFilter = THREE.NearestFilter;
    var wallRGeometry = new THREE.BoxGeometry(0.5, 1.5, 75.0);
    var wallRMaterial = new THREE.MeshPhongMaterial({
        map: rightRingWall,
        shading: THREE.SmoothShading
    });
    rightRingWallMesh = new THREE.Mesh(wallRGeometry, wallRMaterial);
    rightRingWallMesh.position.set(10.0, -6.5, -23.0);
    rightRingWallMesh.castShadow = true;
    rightRingWallMesh.receiveShadow = true;
    scene.add(rightRingWallMesh);
    //?

    //? << Surface >>
    var surfaceTexture = new THREE.TextureLoader().load('texture/floor2.jpg');
    surfaceTexture.repeat.set(5, 1);
    surfaceTexture.wrapS = THREE.RepeatWrapping;
    surfaceTexture.wrapT = THREE.RepeatWrapping;
    surfaceTexture.magFilter = THREE.NearestFilter;
    surfaceTexture.minFilter = THREE.LinearMipMapLinearFilter;
    var surfaceGeometry = new THREE.PlaneGeometry(70, 80);
    var surfaceMaterial = new THREE.MeshPhongMaterial({ color: 0xcccccc, side: THREE.DoubleSide, map: surfaceTexture });
    surfaceMesh = new THREE.Mesh(surfaceGeometry, surfaceMaterial);
    surfaceMesh.rotateX(-Math.PI / 2);
    surfaceMesh.position.y = -5;
    surfaceMesh.position.z = -20;
    surfaceMesh.receiveShadow = true;
    scene.add(surfaceMesh);
    //?
    //********************************** << *** >> ****************************************

    //********************************** << Shapes >> ****************************************
    //? << Bowling Ball >> 
    let bowlingBallTexture = THREE.ImageUtils.loadTexture('texture/ballImages/SoftballColor.jpg');
    bowlingBallTexture.magFilter = THREE.NearestFilter;
    bowlingBallTexture.minFilter = THREE.NearestFilter;
    let bowlingBallGeometry = new THREE.SphereGeometry(1.0, 20, 20);
    var bowlingBallMaterial = new THREE.MeshPhongMaterial({
        map: bowlingBallTexture,
        shading: THREE.SmoothShading
    });
    ball = new THREE.Mesh(bowlingBallGeometry, bowlingBallMaterial);
    ball.castShadow = true;
    ball.receiveShadow = true;
    balls.push(ball);
    scene.add(balls[0]);
    //?

    //?  << Pins >> 
    var objectLoader = new THREE.ObjectLoader();
    for (let pinNumber = 0; pinNumber < 10; pinNumber++) {
        objectLoader.load("model/bowling-pin.json", function (obj) {
            objectMesh = obj;
            objectMesh.scale.set(1.5, 1.5, 1.5);
            objectMesh.receiveShadow = true;
            objectMesh.castShadow = true;
            scene.add(objectMesh);
            pinArray.push(objectMesh);
        });
    };
    //?
    //********************************** << *** >> ****************************************

    //********************************** << Light >> ****************************************
    //? << Point Light >>
    pointLight = new THREE.PointLight(0xffffff, 1, 800, 4);
    pointLight.position.set(0, 20, 0);
    pointLight.castShadow = true;
    pointLight.shadow.camera.near = 1;
    pointLight.shadow.camera.far = 200;
    pointLight.intensity = 1;
    scene.add(pointLight);
    //?

    //? << Spot Light >>
    //? Near
    nearSpotLight = new THREE.SpotLight(0xffef00);
    nearSpotLight.angle = 0.8;
    nearSpotLight.penumbra = 1;
    nearSpotLight.position.set(0, 10, -2);
    nearSpotLight.castShadow = true;
    nearSpotLight.intensity = 0.5;
    nearSpotLight.shadow.mapSize.width = 512;
    nearSpotLight.shadow.mapSize.height = 512;
    nearSpotLight.shadow.camera.near = 0.5;
    nearSpotLight.shadow.camera.far = 500;
    nearSpotLight.visible = true;
    scene.add(nearSpotLight);

    //? Middle
    middleSpotLight = new THREE.SpotLight(0xffef00);
    middleSpotLight.angle = 0.8;
    middleSpotLight.penumbra = 1;
    middleSpotLight.position.set(0, 10, -19);
    middleSpotLight.castShadow = true;
    middleSpotLight.intensity = 0.5;
    middleSpotLight.target.position.set(0, 0, -19)
    middleSpotLight.target.updateMatrixWorld();
    middleSpotLight.shadow.mapSize.width = 512;
    middleSpotLight.shadow.mapSize.height = 512;
    middleSpotLight.shadow.camera.near = 0.5;
    middleSpotLight.shadow.camera.far = 500;
    middleSpotLight.visible = true;
    scene.add(middleSpotLight);

    //? Far
    farSpotLight = new THREE.SpotLight(0xffef00);
    farSpotLight.angle = 0.8;
    farSpotLight.penumbra = 1;
    farSpotLight.position.set(0, 10, -42);
    farSpotLight.castShadow = true;
    farSpotLight.intensity = 0.5;
    farSpotLight.target.position.set(0, 0, -42)
    farSpotLight.target.updateMatrixWorld();
    farSpotLight.shadow.mapSize.width = 512;
    farSpotLight.shadow.mapSize.height = 512;
    farSpotLight.shadow.camera.near = 0.5;
    farSpotLight.shadow.camera.far = 500;
    farSpotLight.visible = true;
    scene.add(farSpotLight);
    //?
    //********************************** << *** >> ****************************************
};


function initCannon() { 
    //? World Setup
    world = new CANNON.World();
    world.gravity.set(0, -26, 0);
    world.broadphase = new CANNON.NaiveBroadphase();
    world.solver.iterations = 20;
    world.defaultContactMaterial.contactEquationStiffness = 1e9;
    world.defaultContactMaterial.contactEquationRelaxation = 4;

    //********************************** << Cannon && Physics >> ****************************************
    //? << Stand Ball Table >>
    tableShape = new CANNON.Box(new CANNON.Vec3(7, 2.0, 1.0));
    tableBody = new CANNON.Body({ mass: 500 });
    tableBody.addShape(tableShape);
    tableBody.angularDamping = 0.5;
    tableBody.position.set(0, 0, 7);
    world.add(tableBody);
    //?

    //? <<Bowling Ball >>
    ballShape = new CANNON.Sphere(1.1);
    ballBody = new CANNON.Body({ mass: 700 });
    ballBody.addShape(ballShape);
    //اصطکاک
    ballBody.angularDamping = 0.3;
    ballBody.position.set(-6, 5, 7);
    ballsBodys.push(ballBody);
    world.add(ballsBodys[0]);
    //?


    //? << Right Front Wall >>
    wallShape2 = new CANNON.Box(new CANNON.Vec3(7.5, 3.5, 3));
    wallBody2 = new CANNON.Body({ mass: 120000 });
    wallBody2.addShape(wallShape2);
    wallBody2.angularDamping = 0.5;
    wallBody2.position.set(18, 0, -59);
    world.add(wallBody2);
    //?

    //? << Left Front Wall >>
    wallShape3 = new CANNON.Box(new CANNON.Vec3(7.5, 3.5, 3));
    wallBody3 = new CANNON.Body({ mass: 120000 });
    wallBody3.addShape(wallShape3);
    wallBody3.angularDamping = 0.5;
    wallBody3.position.set(-18, 0, -59);
    world.add(wallBody3);
    //?

    //? << Main Front Wall >> 
    wallShape = new CANNON.Box(new CANNON.Vec3(25, 12, 20));
    wallBody = new CANNON.Body({ mass: 100000 });
    wallBody.addShape(wallShape);
    wallBody.angularDamping = 0.5;
    wallBody.position.set(0, 15, -57);
    world.add(wallBody);
    //?


    //? << Left Ring Wall >>
    var leftRingWallShape = new CANNON.Box(new CANNON.Vec3(0.25, 1.0, 35.0));
    leftRingWallBody = new CANNON.Body({ mass: 500 });
    leftRingWallBody.addShape(leftRingWallShape);
    leftRingWallBody.angularDamping = 1;
    leftRingWallBody.position.set(-10.0, -4, -18.0);
    world.add(leftRingWallBody);
    //? 

    //? << Right Ring Wall >>
    var rightRingWallShape = new CANNON.Box(new CANNON.Vec3(0.25, 1.0, 35.0));
    rightRingWallBody = new CANNON.Body({ mass: 500 });
    rightRingWallBody.addShape(rightRingWallShape);
    rightRingWallBody.angularDamping = 1;
    rightRingWallBody.position.set(10.0, -4, -18.0);
    world.add(rightRingWallBody);
    //?

    //? << Bowling Pins >>
    let xLocation = [-4.5, -1.5, 1.5, 4.5, -3, 0, 3, -1.5, 1.5, 0], yLocation = 1.0, zLocation = [-53, -53, -53, -53, -48, -48, -48, -43, -43, -38];
    for (let pinNumber = 0; pinNumber < 10; pinNumber++) {
        pinShape = new CANNON.Box(new CANNON.Vec3(0.5, 1.5, 0.5));
        pinBody = new CANNON.Body({ mass: 0.5 });
        pinBody.addShape(pinShape);
        pinBody.angularDamping = 0.5;
        pinBody.position.set(xLocation[pinNumber], yLocation, zLocation[pinNumber]);
        pinArrayBody.push(pinBody);
    };
    for (let number = 0; number < pinArrayBody.length; number++) {
        world.add(pinArrayBody[number]);
    };
    //?
    
    //? << Ground (Floor) >> 
    groundShape = new CANNON.Plane();
    groundBody = new CANNON.Body({ mass: 0 });
    groundBody.addShape(groundShape);
    world.add(groundBody);
    groundBody.position.copy(surfaceMesh.position);
    groundBody.quaternion.copy(surfaceMesh.quaternion);
    //?
    //********************************** << *** >> ****************************************

    


    cannonDebugRenderer = new THREE.CannonDebugRenderer(scene, world);
};



function animate() {
    
    requestAnimationFrame(animate);
    updatePhysics();
    if (phsyicRenderer)
        cannonDebugRenderer.update();
    render();
};

function updatePhysics() {
    //? << Main setup for Cannon JS >>
    world.step(timeStep);

    //********************************** << Merge Mesh & Physic >> ****************************************
    //? << Bowling Pins >> 
    for (let number = 0; number < pinArrayBody.length; number++) {
        pinArray[number].position.copy(pinArrayBody[number].position);
        pinArray[number].quaternion.copy(pinArrayBody[number].quaternion);
    };
    //? 

    //? << Bowling Balls >>
    balls[0].position.copy(ballsBodys[0].position);
    balls[0].quaternion.copy(ballsBodys[0].quaternion);
    //? 

    //? << Left Ring Wall >> 
    leftRingWallMesh.position.copy(leftRingWallBody.position);
    leftRingWallMesh.quaternion.copy(leftRingWallBody.quaternion);
    //? 

    //? << Right Ring Wall >>
    rightRingWallMesh.position.copy(rightRingWallBody.position);
    rightRingWallMesh.quaternion.copy(rightRingWallBody.quaternion);
    //?

    //? << Right Front Wall >>
    testMesh.position.copy(wallBody2.position);
    testMesh.quaternion.copy(wallBody2.quaternion);
    //? 

    //? << Left Front Wall >>
    testMesh10.position.copy(wallBody3.position);
    testMesh10.quaternion.copy(wallBody3.quaternion);
    //?

    //? << Main Front Wall >>
    frontWallMesh.position.copy(wallBody.position);
    frontWallMesh.quaternion.copy(wallBody.quaternion);

}

function render() {
    renderer.render(scene, camera);
    ballMove();
    camera.updateMatrixWorld();
};

var seconds_passed = 0
function onDocumentKeyDown(event) {
    if (event.keyCode == 13) {
        power++
    }

}

var i = 0;
async function onDocumentKeyUp(event) {
    if (event.keyCode == 13) {
        // console.log("power", power);
        

        //? در اینجا قدرت و شیب حرکت توپ را تعیین کردیم
        if (countBall < 1)
            ballsBodys[countBall].velocity.set(0, -20, - (power * 2));
        countBall++;

        if (countBall >= 1) {

            //? بعد از پرتاپ توپ 3 ثانیه صبر میکند و سپس دوربین را جلو میبرد
            await setTimeout(function () {
                camera.position.x = 0;
                camera.position.y = 5;
                camera.position.z = -20;
                camera.lookAt(table.position);
            }, 3000);
            setInterval(function(){
                if(flag1){
                    let scorescore = document.getElementById("scorestate");
                    scorescore.innerHTML = checked();
                    flag1 = 0;
                }
                
                 }
            ,10000);
            
            
            

        }
    }
}

// function Rel() {
//     document.location.reload(true);
// }

// Get the scorePage

// var span = document.getElementsByClassName("close")[0];



function checked() {

        for (var j = 0; j < 10; j = j + 1) {
            if (pinArrayBody[j].position.z < -55) {
                scores = scores + 10;
            }
        }
        console.log(scores)
        return scores;
        
}


function ballMove() {
    //? چرخش توپ به چپ و راست قبل از پرتاپ
    if (counter1 < 50) {
        if (countBall <= 0) {
            ballsBodys[0].position.x += 0.25;
        }
        counter1++;
    }
    else if (counter2 < 50 && counter1 == 50) {
        if (countBall <= 0) {
            ballsBodys[0].position.x -= 0.25;
        }
        counter2++;
    }
    else {
        counter1 = 0;
        counter2 = 0;
    }
}

//? << برای اینکه اگر سایز مرور گر کوچک یا بزرگ >>
function onWindowResize() {
    camera.aspect = window.innerWidth / window.innerHeight;
    camera.updateProjectionMatrix();
    renderer.setSize(window.innerWidth, window.innerHeight);
}