# graphicProjects
Collection of graphic exercises and final project
## Tamrin 
They are WebGl and Three JS exercises.
## _project
The final Three JS project
## Documents
The final project document.
## Attention!
Please use HTTP Server like Apache for create local host OR fix "cross origin requests are only supported for protocol schemes: http, data, chrome, chrome-extension, https" on Google Chrome, Mozila Firefox, Opera and stuff.
We didn't see this error on Microsoft Edge.
## Developers
```diff
+ Hossein Motamen
+ Mahdi Nasiri
+ Mahdi Yasini
+ Sina Rahimian (limited on exercises)
```
